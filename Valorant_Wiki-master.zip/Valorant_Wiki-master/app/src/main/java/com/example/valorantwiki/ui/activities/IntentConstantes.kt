package com.example.valorantwiki.ui.activities

const val AGENT_UUID = "agent_uuid"
const val MAP_UUID = "map_uuid"
const val WEAPON_UUID = "weapon_uuid"