package com.example.valorantwiki.ui.activities.extensions

fun String.formatStrToColorStr(): String = this.substring(0, this.length - 2)