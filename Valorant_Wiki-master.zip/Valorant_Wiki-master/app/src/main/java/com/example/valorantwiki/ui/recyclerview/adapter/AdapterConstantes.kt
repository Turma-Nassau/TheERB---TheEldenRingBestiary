package com.example.valorantwiki.ui.recyclerview.adapter

const val TAG = "Testes Adapter"