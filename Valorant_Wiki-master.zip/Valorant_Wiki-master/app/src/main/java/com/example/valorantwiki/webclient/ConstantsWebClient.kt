package com.example.valorantwiki.webclient

const val TAG = "Requisição Web API"
const val SUCCESS_CODE = 200